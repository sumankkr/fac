(function ($)
{
     $("#slideshow > div:gt(0)").hide();

    $(document).ready(function() {  

             $("#test").load("template.html");
             $("#test2").load("b_template2.html");
             $("#test3").load("b_template3.html");
             





            /*$("#test").html("../html/template.html");
            console.log('here too');*/

           

            // setInterval(function() { 
            //   $('#slideshow > div:first')
            //     .fadeOut(1000)
            //     .next()
            //     .fadeIn(1000)
            //     .end()
            //     .appendTo('#slideshow');
            // },  3000);

            $("#next-btn").click(function (){
            	 $('#slideshow > div:first')
                .fadeOut(1000)
                .next()
                .fadeIn(1000)
                .end()
                .appendTo('#slideshow');

            })
            $("#prev-btn").click(function (){
            	 $('#slideshow > div:first')
                .fadeOut(1000)
                .end;

                $("#slideshow > div:last")
                .fadeIn(1000)
                .end();

                $("#slideshow > div:last").prependTo('#slideshow');

            })

            
        }); //Docuemnt ready end.
    



})(jQuery); //IIFE end.